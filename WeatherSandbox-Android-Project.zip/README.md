# 2D Weather Sandbox Android wrapper

This project packages the original 2D Weather Sandbox website inside an Android WebView for offline use.

The original simulation source, scripts, shaders, libraries, and resources are stored in `app/src/main/assets/site/`.
Saved example worlds and documentation are excluded to keep the upload small. The app can create or use its own local data, but pre-packaged saved worlds are not included.

Build with `gradle assembleDebug`.
