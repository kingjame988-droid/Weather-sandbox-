
plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.weathersandbox"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.weathersandbox"
        minSdk = 24
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
}

